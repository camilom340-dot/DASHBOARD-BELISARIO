import clsx from "clsx";
export function Card({ className, children }:{ className?: string; children: React.ReactNode }) {
  return <div className={clsx("rounded-2xl bg-white shadow-soft border border-zinc-100", className)}>{children}</div>;
}
export function CardHeader({ title, subtitle, right }:{ title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <div className="px-5 py-4 border-b border-zinc-100 flex items-start justify-between gap-4">
      <div>
        <div className="text-sm font-semibold text-zinc-900">{title}</div>
        {subtitle ? <div className="text-xs text-zinc-500 mt-1">{subtitle}</div> : null}
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}
export function CardBody({ className, children }:{ className?: string; children: React.ReactNode }) {
  return <div className={clsx("p-5", className)}>{children}</div>;
}
export function Badge({ tone, children }:{ tone: "green"|"yellow"|"red"|"gray"; children: React.ReactNode }) {
  const styles: Record<string,string> = {
    green:"bg-emerald-50 text-emerald-700 border-emerald-200",
    yellow:"bg-amber-50 text-amber-700 border-amber-200",
    red:"bg-rose-50 text-rose-700 border-rose-200",
    gray:"bg-zinc-50 text-zinc-700 border-zinc-200",
  };
  return <span className={clsx("inline-flex items-center px-2 py-1 rounded-full text-xs border", styles[tone])}>{children}</span>;
}
export function Toggle({ checked, onChange, labelLeft, labelRight }:{
  checked: boolean; onChange:(v:boolean)=>void; labelLeft: string; labelRight: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className={clsx("text-xs", !checked ? "text-zinc-900 font-medium" : "text-zinc-500")}>{labelLeft}</span>
      <button type="button" onClick={() => onChange(!checked)} className={clsx("relative w-11 h-6 rounded-full border", checked ? "bg-zinc-900 border-zinc-900" : "bg-zinc-200 border-zinc-200")} aria-pressed={checked}>
        <span className={clsx("absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-5" : "translate-x-0.5")} />
      </button>
      <span className={clsx("text-xs", checked ? "text-zinc-900 font-medium" : "text-zinc-500")}>{labelRight}</span>
    </div>
  );
}
