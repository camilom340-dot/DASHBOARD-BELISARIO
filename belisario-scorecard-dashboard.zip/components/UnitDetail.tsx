import { AreaDef, Unit } from "@/lib/types";
import { Card, CardBody, CardHeader, Badge } from "@/components/ui";
import { ScoreBreakdown } from "@/lib/types";
import { trafficLight } from "@/lib/score";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

const fmt = (n:number) => Number.isFinite(n) ? n.toFixed(4) : "-";

export function UnitDetail({ unit, areas, breakdown, onBack }:{
  unit: Unit; areas: AreaDef[]; breakdown: ScoreBreakdown; onBack?:()=>void;
}) {
  const tone = trafficLight(breakdown.scoreTotal);
  const areaBars = areas.map(a => {
    const s = breakdown.scoreByArea[a.id];
    return { area: a.name, ganado: s.gained, posible: s.possible, cobertura: Math.round((s.coverage||0)*100) };
  });
  const topLost = [...breakdown.kpiScored].filter(x => x.pointsLost > 0.000001).sort((a,b)=>b.pointsLost-a.pointsLost).slice(0,12);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-xl font-semibold">{unit.name}</div>
          <div className="text-sm text-zinc-500">{unit.type === "restaurant" ? "Restaurante" : "Discoteca"} · Score {fmt(breakdown.scoreTotal)}</div>
        </div>
        <div className="flex items-center gap-3">
          <Badge tone={tone}>{(breakdown.scoreTotal*100).toFixed(0)}%</Badge>
          {onBack ? <button onClick={onBack} className="text-sm underline text-zinc-700 hover:text-zinc-900">Volver</button> : null}
        </div>
      </div>

      <Card>
        <CardHeader title="Composición del score por áreas" subtitle="Ganado vs posible (según modo de faltantes)" />
        <CardBody className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={areaBars} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="area" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[0,1]} />
              <Tooltip formatter={(v:any)=> typeof v === "number" ? v.toFixed(4) : v} />
              <Bar dataKey="posible" />
              <Bar dataKey="ganado" />
            </BarChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Top KPIs que más quitan puntos" subtitle="Ordenado por puntos perdidos" />
        <CardBody>
          <div className="overflow-auto">
            <table className="min-w-[980px] w-full text-sm">
              <thead>
                <tr className="text-xs text-zinc-500">
                  <th className="text-left font-medium p-2">KPI</th>
                  <th className="text-left font-medium p-2">Área</th>
                  <th className="text-left font-medium p-2">Indicador</th>
                  <th className="text-left font-medium p-2">Regla</th>
                  <th className="text-left font-medium p-2">Cumple</th>
                  <th className="text-left font-medium p-2">Perdidos</th>
                  <th className="text-left font-medium p-2">Posibles</th>
                </tr>
              </thead>
              <tbody>
                {topLost.map(r => (
                  <tr key={r.kpi.id} className="border-t border-zinc-100">
                    <td className="p-2 font-medium">{r.kpi.name}</td>
                    <td className="p-2 text-zinc-700">{areas.find(a=>a.id===r.kpi.areaId)?.name ?? r.kpi.areaId}</td>
                    <td className="p-2 tabular-nums">{r.value ?? "-"}</td>
                    <td className="p-2 tabular-nums">{r.kpi.operator} {r.kpi.param}</td>
                    <td className="p-2">{r.meets === null ? <span className="text-xs text-zinc-500">No evaluable</span> : r.meets ? <span className="text-xs text-emerald-700">Sí</span> : <span className="text-xs text-rose-700">No</span>}</td>
                    <td className="p-2 tabular-nums font-semibold">{r.pointsLost.toFixed(4)}</td>
                    <td className="p-2 tabular-nums">{r.pointsPossible.toFixed(4)}</td>
                  </tr>
                ))}
                {topLost.length === 0 ? <tr><td className="p-3 text-zinc-500" colSpan={7}>No hay puntos perdidos (o no hay datos).</td></tr> : null}
              </tbody>
            </table>
          </div>

          <div className="mt-4">
            <div className="text-sm font-semibold">Qué arreglar primero</div>
            <ul className="mt-2 text-sm text-zinc-700 list-disc pl-5">
              {topLost.slice(0,5).map((r, i) => (
                <li key={r.kpi.id}>{i+1}) <span className="font-medium">{r.kpi.name}</span>: pierdes {r.pointsLost.toFixed(4)} puntos</li>
              ))}
            </ul>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
