import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
export function Histogram({ scores }:{ scores: number[] }) {
  const bins = Array.from({ length: 10 }, (_, i) => ({ bin: `${i*10}-${i*10+9}`, count: 0 }));
  for (const s of scores) {
    const idx = Math.min(9, Math.max(0, Math.floor(s * 10)));
    bins[idx].count += 1;
  }
  return (
    <div className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={bins} margin={{ top: 10, right: 10, left: 0, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="bin" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
          <Tooltip />
          <Bar dataKey="count" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
