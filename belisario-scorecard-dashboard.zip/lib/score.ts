import { AreaDef, AreaId, KpiDef, Operator, ScoreBreakdown, UnitPeriodData } from "@/lib/types";
export type MissingMode = "excel" | "normalized";

export function trafficLight(scoreTotal: number): "green" | "yellow" | "red" {
  if (scoreTotal >= 0.70) return "green";
  if (scoreTotal >= 0.50) return "yellow";
  return "red";
}
function compare(value: number, op: Operator, param: number): boolean {
  switch (op) { case ">": return value > param; case ">=": return value >= param; case "<": return value < param; case "<=": return value <= param; }
}
function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function computeScores(unitData: UnitPeriodData, areas: AreaDef[], kpis: KpiDef[], mode: MissingMode): ScoreBreakdown {
  const scoreByArea = {} as ScoreBreakdown["scoreByArea"];
  areas.forEach(a => { scoreByArea[a.id] = { gained: 0, possible: 0, coverage: 0 }; });

  const kpisByArea: Record<AreaId, KpiDef[]> = { ECONOMICO: [], OPERATIVO: [], SERVICIO: [], MERCADEO: [], RRHH: [] };
  for (const k of kpis) kpisByArea[k.areaId].push(k);

  const kpiScored: ScoreBreakdown["kpiScored"] = [];

  for (const area of areas) {
    const list = kpisByArea[area.id] ?? [];
    let evaluableWeightSum = 0, evaluableCount = 0, totalCount = list.length;

    for (const k of list) {
      const val = unitData.results[k.id]?.value ?? null;
      if (val !== null && Number.isFinite(val)) { evaluableWeightSum += k.weightInArea; evaluableCount += 1; }
    }
    scoreByArea[area.id].coverage = totalCount === 0 ? 1 : evaluableCount / totalCount;

    for (const k of list) {
      const val = unitData.results[k.id]?.value ?? null;

      const pointsPossible =
        mode === "excel"
          ? area.weight * k.weightInArea
          : (val === null ? 0 : area.weight * (k.weightInArea / (evaluableWeightSum || 1)));

      const meets = val === null ? (mode === "excel" ? false : null) : compare(val, k.operator, k.param);
      const pointsGained = meets === true ? pointsPossible : 0;
      const pointsLost = pointsPossible - pointsGained;

      scoreByArea[area.id].possible += pointsPossible;
      scoreByArea[area.id].gained += pointsGained;

      kpiScored.push({ kpi: k, value: val, meets, pointsPossible, pointsGained, pointsLost });
    }
  }

  const scoreTotal = areas.reduce((acc, a) => acc + scoreByArea[a.id].gained, 0);

  for (const a of areas) {
    scoreByArea[a.id].gained = clamp01(scoreByArea[a.id].gained);
    scoreByArea[a.id].possible = clamp01(scoreByArea[a.id].possible);
  }

  return { scoreTotal: clamp01(scoreTotal), scoreByArea, kpiScored };
}
