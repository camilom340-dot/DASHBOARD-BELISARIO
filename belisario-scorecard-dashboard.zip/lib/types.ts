export type UnitType = "restaurant" | "disco";
export type AreaId = "ECONOMICO" | "OPERATIVO" | "SERVICIO" | "MERCADEO" | "RRHH";
export type Operator = ">" | ">=" | "<" | "<=";

export interface AreaDef { id: AreaId; name: string; weight: number; order: number; }
export interface KpiDef { id: string; areaId: AreaId; name: string; weightInArea: number; operator: Operator; param: number; format?: "percent" | "currency" | "ratio" | "number"; description?: string; }
export interface KpiResult { kpiId: string; value: number | null; }
export interface Unit { id: string; name: string; type: UnitType; }
export interface UnitPeriodData { unit: Unit; results: Record<string, KpiResult>; }
export interface ScoreBreakdown {
  scoreTotal: number;
  scoreByArea: Record<AreaId, { gained: number; possible: number; coverage: number }>;
  kpiScored: Array<{ kpi: KpiDef; value: number | null; meets: boolean | null; pointsPossible: number; pointsGained: number; pointsLost: number; }>;
}
