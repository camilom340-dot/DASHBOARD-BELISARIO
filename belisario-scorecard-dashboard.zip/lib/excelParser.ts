import * as XLSX from "xlsx";
import { AreaDef, AreaId, KpiDef, Operator, Unit, UnitPeriodData } from "@/lib/types";

export const DEFAULT_AREAS: AreaDef[] = [
  { id: "ECONOMICO", name: "Económico", weight: 0.65, order: 1 },
  { id: "OPERATIVO", name: "Operativo", weight: 0.10, order: 2 },
  { id: "SERVICIO", name: "Servicio", weight: 0.10, order: 3 },
  { id: "MERCADEO", name: "Mercadeo", weight: 0.10, order: 4 },
  { id: "RRHH", name: "RRHH", weight: 0.05, order: 5 },
];

const AREA_ALIASES: Record<AreaId, RegExp[]> = {
  ECONOMICO: [/ECONOM/i, /ECONÓM/i],
  OPERATIVO: [/OPERATIV/i],
  SERVICIO: [/SERVIC/i],
  MERCADEO: [/MERCAD/i],
  RRHH: [/RRHH/i, /R\s*R\s*H\s*H/i, /TALENTO/i],
};

const asString = (v: any) => String(v ?? "").trim();
function asNumber(v: any): number | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim().replace(/\./g, "").replace(/,/g, ".");
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}
function detectOperator(text: string): Operator {
  const t = text.replace(/\s+/g, "");
  if (t.includes(">=")) return ">=";
  if (t.includes("<=")) return "<=";
  if (t.includes(">")) return ">";
  if (t.includes("<")) return "<";
  return ">=";
}
type SheetMatrix = any[][];
function sheetToMatrix(ws: XLSX.WorkSheet): SheetMatrix {
  const range = XLSX.utils.decode_range(ws["!ref"] || "A1:A1");
  const out: any[][] = [];
  for (let r = range.s.r; r <= range.e.r; r++) {
    const row: any[] = [];
    for (let c = range.s.c; c <= range.e.c; c++) {
      const addr = XLSX.utils.encode_cell({ r, c });
      row.push(ws[addr]?.v ?? null);
    }
    out.push(row);
  }
  return out;
}

function getUnitColumns(matrix: SheetMatrix) {
  let headerRowIdx = -1;
  for (let r = 0; r < Math.min(matrix.length, 20); r++) {
    const row = matrix[r].map(asString);
    const iCount = row.filter(x => /INDICADOR/i.test(x)).length;
    const cCount = row.filter(x => /CALIFIC/i.test(x)).length;
    if (iCount >= 2 && cCount >= 2) { headerRowIdx = r; break; }
  }
  if (headerRowIdx === -1) headerRowIdx = 1;
  const nameRowIdx = Math.max(0, headerRowIdx - 1);
  const headerRow = matrix[headerRowIdx].map(asString);
  const nameRow = matrix[nameRowIdx].map(asString);

  const cols: Array<{ unitId: string; indicatorCol: number; }> = [];
  const units: Unit[] = [];

  for (let c = 0; c < headerRow.length; c++) {
    if (/INDICADOR/i.test(headerRow[c])) {
      const unitName = nameRow[c] || `Unidad ${c}`;
      const unitId = unitName.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_áéíóúñ]/gi, "");
      cols.push({ unitId, indicatorCol: c });
      units.push({ id: unitId, name: unitName, type: "restaurant" });
    }
  }
  const seen = new Set<string>();
  const u2: Unit[] = [];
  const c2: typeof cols = [];
  for (let i = 0; i < cols.length; i++) {
    if (seen.has(units[i].id)) continue;
    seen.add(units[i].id);
    u2.push(units[i]);
    c2.push(cols[i]);
  }
  return { units: u2, cols: c2 };
}

function scanKpiRows(matrix: SheetMatrix) {
  const rows: Array<{ areaId: AreaId; rowIdx: number; name: string; weightInArea: number; operator: Operator; param: number; }> = [];
  let currentArea: AreaId | null = null;

  for (let r = 0; r < matrix.length; r++) {
    const row = matrix[r];
    const rowText = row.map(asString).filter(Boolean).join(" ").trim();

    for (const areaId of Object.keys(AREA_ALIASES) as AreaId[]) {
      if (AREA_ALIASES[areaId].some(rx => rx.test(rowText))) { currentArea = areaId; break; }
    }
    if (!currentArea) continue;

    const c0 = asString(row[0]);
    const c1 = asString(row[1]);
    const name = (c0 && c0.length > 2 ? c0 : c1);
    if (!name) continue;
    if (/TOTAL/i.test(name) || /CALIFICACI/i.test(name) || /INDICADOR/i.test(name)) continue;

    let weight: number | null = null;
    let param: number | null = null;
    let op: Operator = ">=";

    for (let c = 0; c < Math.min(12, row.length); c++) {
      const cell = asString(row[c]);
      if (!cell) continue;
      if (/[<>]/.test(cell)) op = detectOperator(cell);
      const num = asNumber(cell);
      if (num !== null) {
        if (weight === null && num > 0 && num <= 1) weight = num;
        else if (param === null) param = num;
      }
    }
    if (weight === null || param === null) continue;
    rows.push({ areaId: currentArea, rowIdx: r, name, weightInArea: weight, operator: op, param });
  }

  const seen = new Set<string>();
  const out: typeof rows = [];
  for (const x of rows) {
    const key = `${x.areaId}::${x.name.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(x);
  }
  return out;
}

export interface ParsedScorecard { areas: AreaDef[]; kpis: KpiDef[]; units: Unit[]; unitData: UnitPeriodData[]; }

export function parseBelisarioExcel(file: ArrayBuffer): ParsedScorecard {
  const wb = XLSX.read(file, { type: "array" });
  const wsRest = wb.Sheets["RESTAURANTES"];
  const wsDisco = wb.Sheets["DISCOTECAS"];
  if (!wsRest && !wsDisco) throw new Error("No encontré hojas 'RESTAURANTES' ni 'DISCOTECAS'.");

  const areas = DEFAULT_AREAS;
  const kpis: KpiDef[] = [];
  const units: Unit[] = [];
  const unitData: UnitPeriodData[] = [];

  function parseSheet(ws: XLSX.WorkSheet, type: Unit["type"]) {
    const matrix = sheetToMatrix(ws);
    const { units: sheetUnits, cols } = getUnitColumns(matrix);
    sheetUnits.forEach(u => (u.type = type));
    units.push(...sheetUnits);

    const kpiRows = scanKpiRows(matrix);
    for (const r of kpiRows) {
      const id = `${r.areaId}_${r.name}`.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_áéíóúñ]/gi, "");
      if (!kpis.find(k => k.id === id)) kpis.push({ id, areaId: r.areaId, name: r.name, weightInArea: r.weightInArea, operator: r.operator, param: r.param });
    }

    for (const u of sheetUnits) {
      const col = cols.find(c => c.unitId === u.id);
      if (!col) continue;
      const results: UnitPeriodData["results"] = {};
      for (const r of kpiRows) {
        const id = `${r.areaId}_${r.name}`.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_áéíóúñ]/gi, "");
        const value = asNumber(matrix[r.rowIdx]?.[col.indicatorCol] ?? null);
        results[id] = { kpiId: id, value };
      }
      unitData.push({ unit: u, results });
    }
  }

  if (wsRest) parseSheet(wsRest, "restaurant");
  if (wsDisco) parseSheet(wsDisco, "disco");

  // normalize weights within each area
  const sums: Record<AreaId, number> = { ECONOMICO: 0, OPERATIVO: 0, SERVICIO: 0, MERCADEO: 0, RRHH: 0 };
  for (const k of kpis) sums[k.areaId] += k.weightInArea;
  for (const k of kpis) k.weightInArea = k.weightInArea / (sums[k.areaId] || 1);

  return { areas, kpis, units, unitData };
}
