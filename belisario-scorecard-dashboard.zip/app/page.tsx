"use client";
import { useMemo, useState } from "react";
import { parseBelisarioExcel } from "@/lib/excelParser";
import { computeScores, trafficLight } from "@/lib/score";
import type { MissingMode } from "@/lib/score";
import type { AreaId } from "@/lib/types";
import { Card, CardBody, CardHeader, Toggle } from "@/components/ui";
import { RankingTable } from "@/components/RankingTable";
import { Heatmap } from "@/components/Heatmap";
import { UnitDetail } from "@/components/UnitDetail";
import { TopCards } from "@/components/TopCards";
import { Histogram } from "@/components/Histogram";

export default function Page() {
  const [parsed, setParsed] = useState<any>(null);
  const [mode, setMode] = useState<MissingMode>("excel");
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<"all"|"restaurant"|"disco">("all");
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    if (!parsed) return [];
    return parsed.unitData.map((ud:any) => {
      const breakdown = computeScores(ud, parsed.areas, parsed.kpis, mode);
      return { unit: ud.unit, scoreTotal: breakdown.scoreTotal, scoreByArea: breakdown.scoreByArea };
    }).sort((a:any,b:any)=>b.scoreTotal-a.scoreTotal);
  }, [parsed, mode]);

  const filtered = useMemo(() => rows.filter((r:any) => {
    if (filterType !== "all" && r.unit.type !== filterType) return false;
    if (q.trim() && !r.unit.name.toLowerCase().includes(q.trim().toLowerCase())) return false;
    return true;
  }), [rows, filterType, q]);

  const selectedUnitData = useMemo(() => {
    if (!parsed || !selectedUnitId) return null;
    return parsed.unitData.find((x:any)=>x.unit.id===selectedUnitId) ?? null;
  }, [parsed, selectedUnitId]);

  const selectedBreakdown = useMemo(() => {
    if (!parsed || !selectedUnitData) return null;
    return computeScores(selectedUnitData, parsed.areas, parsed.kpis, mode);
  }, [parsed, selectedUnitData, mode]);

  const stats = useMemo(() => {
    if (!filtered.length) return { avg: 0, green: 0, yellow: 0, red: 0, top: null, bottom: null };
    const avg = filtered.reduce((a:number, r:any)=>a+r.scoreTotal,0)/filtered.length;
    let green=0,yellow=0,red=0;
    for (const r of filtered) {
      const t = trafficLight(r.scoreTotal);
      if (t==="green") green++; else if (t==="yellow") yellow++; else red++;
    }
    const top = filtered[0] ? { name: filtered[0].unit.name, score: filtered[0].scoreTotal } : null;
    const bottom = filtered[filtered.length-1] ? { name: filtered[filtered.length-1].unit.name, score: filtered[filtered.length-1].scoreTotal } : null;
    return { avg, green, yellow, red, top, bottom };
  }, [filtered]);

  function onFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const arr = reader.result as ArrayBuffer;
        const p = parseBelisarioExcel(arr);
        setParsed(p);
        setSelectedUnitId(p.unitData[0]?.unit.id ?? null);
      } catch (e: any) {
        alert(e?.message ?? "No pude leer el Excel.");
      }
    };
    reader.readAsArrayBuffer(file);
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-5 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <div className="text-2xl font-semibold">Dashboard Belisario</div>
            <div className="text-sm text-zinc-500">Scorecard ponderado · visual y accionable</div>
          </div>
          <div className="flex items-center gap-3">
            <Toggle checked={mode==="normalized"} onChange={(v)=>setMode(v?"normalized":"excel")} labelLeft="Tal cual Excel" labelRight="Normalizado" />
            <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-zinc-200 bg-white hover:bg-zinc-50 cursor-pointer">
              <span className="text-sm font-medium">Subir Excel</span>
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={(e)=>{ const f=e.target.files?.[0]; if(f) onFile(f); }} />
            </label>
          </div>
        </div>

        {!parsed ? (
          <div className="mt-8">
            <Card>
              <CardHeader title="Cargar el Excel" subtitle="Sube “SABANA BELISARIO ACUMULADA .xlsx” para generar el dashboard." />
              <CardBody>
                <ol className="list-decimal pl-5 text-sm text-zinc-700 space-y-2">
                  <li>Haz clic en <b>Subir Excel</b>.</li>
                  <li>Se calcula score total + por áreas + KPIs con puntos perdidos.</li>
                  <li>Usa <b>Normalizado</b> si no quieres penalizar KPIs sin datos.</li>
                </ol>
              </CardBody>
            </Card>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            <TopCards {...stats} />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card className="lg:col-span-2">
                <CardHeader
                  title="Ranking global"
                  subtitle="Ordenado por score total · clic en una unidad para ver detalle"
                  right={
                    <div className="flex items-center gap-2">
                      <select className="px-3 py-2 rounded-xl border border-zinc-200 bg-white text-sm" value={filterType} onChange={(e)=>setFilterType(e.target.value as any)}>
                        <option value="all">Todos</option>
                        <option value="restaurant">Restaurantes</option>
                        <option value="disco">Discotecas</option>
                      </select>
                      <input className="px-3 py-2 rounded-xl border border-zinc-200 bg-white text-sm w-44" placeholder="Buscar unidad" value={q} onChange={(e)=>setQ(e.target.value)} />
                    </div>
                  }
                />
                <CardBody>
                  <RankingTable
                    areas={parsed.areas}
                    rows={filtered.map((r:any)=>({ unitId:r.unit.id, unitName:r.unit.name, type:r.unit.type, scoreTotal:r.scoreTotal, scoreByArea:r.scoreByArea }))}
                    selectedUnitId={selectedUnitId}
                    onSelect={(id)=>setSelectedUnitId(id)}
                  />
                </CardBody>
              </Card>
              <Card>
                <CardHeader title="Distribución de scores" subtitle="Cómo se reparte el desempeño" />
                <CardBody><Histogram scores={filtered.map((r:any)=>r.scoreTotal)} /></CardBody>
              </Card>
            </div>

            <Card>
              <CardHeader title="Mapa de calor por áreas" subtitle="% ganado por área + cobertura" />
              <CardBody>
                <Heatmap
                  areas={parsed.areas}
                  rows={filtered.map((r:any)=>({ unitId:r.unit.id, unitName:r.unit.name, byArea:r.scoreByArea }))}
                  selectedUnitId={selectedUnitId}
                  onSelect={(id)=>setSelectedUnitId(id)}
                />
              </CardBody>
            </Card>

            {selectedUnitData && selectedBreakdown ? (
              <UnitDetail unit={selectedUnitData.unit} areas={parsed.areas} breakdown={selectedBreakdown} onBack={()=>setSelectedUnitId(null)} />
            ) : null}
          </div>
        )}

        <footer className="py-10 text-xs text-zinc-500">
          Modo <b>{mode==="excel" ? "Tal cual Excel" : "Normalizado"}</b>: {mode==="excel" ? "si falta un KPI, cuenta como 0." : "si falta un KPI, no se evalúa y se recalcula el denominador."}
        </footer>
      </div>
    </div>
  );
}
